<nav>
	<div id="top_menu">
	<a href="index.php?comando=catalogo">Stagione 2015</a>
	<a href="index.php?comando=chi_siamo">Chi siamo</a>
	<a href="index.php?comando=contatti">Contatti</a>
	<a href="index.php?comando=news">News</a>
	<a href="index.php?comando=poltroncine">Poltroncine</a>
	</div>
</nav>