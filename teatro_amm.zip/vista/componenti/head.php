<head>
	<meta charset="UTF-8">
	<meta name="description" content="Esercitazione di AMM">
	<link rel="stylesheet" type="text/css" href="vista/css/stile.css">

   	<script type='text/javascript' src="js/script.js"></script>
	<title>Esercitazione di AMM</title>
</head>


