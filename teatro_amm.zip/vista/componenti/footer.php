
<p>cerchi & triangoli srl  -  p.iva 000000000001  -  2013  -  tutti i diritti riservati  <br/>
	    Applicazione d'esempio per l'esame di Amministrazione di Sistema
	</p>
	<p>
	    <a href="http://validator.w3.org/check/referer" class="xhtml" title="Questa pagina contiene HTML valido">
	        <abbr title="eXtensible HyperText Markup Language">HTML</abbr> Valido</a>
	    <a href="http://jigsaw.w3.org/css-validator/check/referer" class="css" title="Questa pagina ha CSS validi">
	        <abbr title="Cascading Style Sheets">CSS</abbr> Valido</a>
	</p>
