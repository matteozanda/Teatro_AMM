<!DOCTYPE html>

<?php include_once("vista/componenti/head.php"); ?>

<body>
	<div class="wrapper">
		<header>
            <?php include_once("vista/componenti/header_image.php"); ?>
		</header>	
        <?php include_once("vista/componenti/topmenu.php"); 
        include_once("vista/componenti/sidebar_R.php"); ?>

		<div class="page_2colonne">
			<h2>Contattaci</h2>
			<h3>TEATRO DI CASINU</h3>
			
				<p>Via Filodrammatici 2 <br/>
				29991 Casinu <br/>
				Tel. 99 887711</p>

				 <br/>
				
			<h3>BIGLIETTERIA</h3> 
				<p>Biglietteria Centrale - Duomo <br/>
				Galleria del Sagrato, Piazza Del Duomo, 29991 Casinu</p>
			</p>
			<br/>
			<a href="index.php?comando=catalogo">Torna alla Home</a>
		</div>
	    <footer>
	        <?php include_once("vista/componenti/footer.php"); ?>
	    </footer>

    </div>
</body>
