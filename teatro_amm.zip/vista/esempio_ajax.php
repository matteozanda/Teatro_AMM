<?php
	//Script Programmatore PHP
	$tuo_nome = $_POST['nome'];
	echo "<p>Ciao <strong>$tuo_nome</strong>, come stai?</p>";
?>